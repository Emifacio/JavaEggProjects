/*

 */
package Enum;

public enum EspectadorEnum {
    
}
