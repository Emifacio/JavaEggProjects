/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cine;

import Servicios.SimuladorCine;
import cine.Entidades.CineGuia11Ex2;
import cine.Entidades.PeliculaGuia11Ex2;

/**
 *
 * @author ignac
 */
public class Cine {

    /**
     * @param args the command line arguments
     */
  
    public static void main(String[] args) {
        // Crear una película
        PeliculaGuia11Ex2 pelicula = new PeliculaGuia11Ex2("Título de la Película", 120, 12, "Director de la Película");

        // Crear un cine
        CineGuia11Ex2 cine = new CineGuia11Ex2(pelicula, 10.0);

        // Crear un simulador de cine
        SimuladorCine simulador = new SimuladorCine(cine);

        // Generar espectadores aleatorios y ubicarlos en la sala
        simulador.generarEspectadores(28);

        // Mostrar la sala
        simulador.mostrarSala();
    }
}

