/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cine.Entidades;

/**
 *
 * @author ignac
 */
public class PeliculaGuia11Ex2 {

    private String titulo;
    private int duracion;
    private int edadMin;
    private String director;

    public PeliculaGuia11Ex2(String titulo, int duracion, int edadMin, String director) {
        this.titulo = titulo;
        this.duracion = duracion;
        this.edadMin = edadMin;
        this.director = director;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getDuracion() {
        return duracion;
    }

    public int getEdadMin() {
        return edadMin;
    }

    public String getDirector() {
        return director;
    }

}
