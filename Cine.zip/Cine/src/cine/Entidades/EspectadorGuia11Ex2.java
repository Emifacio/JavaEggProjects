/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cine.Entidades;

/**
 *
 * @author ignac
 */
public class EspectadorGuia11Ex2 {
        private String nombre;
    private int edad;
    private double dineroDisponible;

    public EspectadorGuia11Ex2(String nombre, int edad, double dineroDisponible) {
        this.nombre = nombre;
        this.edad = edad;
        this.dineroDisponible = dineroDisponible;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public double getDineroDisponible() {
        return dineroDisponible;
    }

}
