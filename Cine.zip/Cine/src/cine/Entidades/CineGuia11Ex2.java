/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cine.Entidades;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 *
 * @author ignac
 */
public class CineGuia11Ex2 {
      private PeliculaGuia11Ex2 pelicula;
    private EspectadorGuia11Ex2[][] sala;
    private double precioEntrada;

    public CineGuia11Ex2(PeliculaGuia11Ex2 pelicula, double precioEntrada) {
        this.pelicula = pelicula;
        this.precioEntrada = precioEntrada;
        sala = new EspectadorGuia11Ex2[8][6];
    }

    // metodos para obterner info del cine
    public PeliculaGuia11Ex2 getPelicula() {
        return pelicula;
    }

    public double getPrecioEntrada() {
        return precioEntrada;
    }

    public EspectadorGuia11Ex2[][] getSala() {
        return sala;
    }

    // Metodos para asignar un espectador a un asientdo

    public boolean asignarAsiento(EspectadorGuia11Ex2 espectador) {

        int filas = sala.length;
        int columnas = sala[0].length;

        // Crear una lista de todos los asientos disponibles
        List<int[]> asientosDisponibles = new ArrayList<>();
        for (int fila = 0; fila < filas; fila++) {
            for (int columna = 0; columna < columnas; columna++) {
                if (sala[fila][columna] == null) {
                    asientosDisponibles.add(new int[] { fila, columna });
                }
            }
        }

        // Mezclar la lista de asientos disponibles
        Collections.shuffle(asientosDisponibles);

        // Recorrer los asientos mezclados y asignar el primer asiento adecuado al
        // espectador
        for (int[] asiento : asientosDisponibles) {
            int fila = asiento[0];
            int columna = asiento[1];

            if (espectador.getEdad() >= pelicula.getEdadMin() &&
                    espectador.getDineroDisponible() >= precioEntrada) {
                sala[fila][columna] = espectador;
                return true;
            }
        }

        return false;
    }
}
