/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import cine.Entidades.CineGuia11Ex2;
import cine.Entidades.EspectadorGuia11Ex2;
import java.util.Random;

/**
 *
 * @author ignac
 */
public class SimuladorCine {
    private CineGuia11Ex2 cine;

    public SimuladorCine(CineGuia11Ex2 cine) {
        this.cine = cine;
    }

    // metodo para generar espectadores aletaroios y ubicarlos en la sala
    public void generarEspectadores(int cantidadEspectadpres) {
        Random random = new Random();

        for (int i = 0; i < cantidadEspectadpres; i++) {
            String nombre = "Espectador" + (i + 1);
            int edad = random.nextInt(50) + 10;
            double dineroDisponible = random.nextDouble() * 50 + 10;
            EspectadorGuia11Ex2 espectador = new EspectadorGuia11Ex2(nombre, edad, dineroDisponible);
            cine.asignarAsiento(espectador);
        }
    }

    // Método para mostrar la sala con los espectadores
    public void mostrarSala() {
        EspectadorGuia11Ex2[][] sala = cine.getSala();
        System.out.println("Sala de Cine:");

        for (int fila = sala.length - 1; fila >= 0; fila--) {
            for (int columna = 0; columna < sala[fila].length; columna++) {
                EspectadorGuia11Ex2 espectador = sala[fila][columna];
                String asiento = (fila + 1) + "" + (char) ('A' + columna);
                System.out.print(asiento + (espectador != null ? " X | " : "   | "));
            }
            System.out.println();
        }
    }
}
